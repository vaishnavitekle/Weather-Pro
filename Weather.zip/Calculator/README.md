# React Project

This is project is about knowing weather condition by providing city name. User will know the wind speed and humidity of the city.. 
